import java.lang.*;
public class TestBook
{
    public static void main(String[] args)
    {
        Book b1 = new Book("Pushkin",240 );
        Book b2 = new Book("Tolstoi", 40);
        Book b3 = new Book("Chehov",70);
            System.out.println(b1);
            b1.InfoBook();
            b2.InfoBook();
            b3.InfoBook();
    }
}
