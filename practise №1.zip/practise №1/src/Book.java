public class Book
{
    private String producer;
    private int price;
    public Book (String c , int price)
    {
        producer = c;
        this.price = price;
    }
    public Book (String c)
    {
        producer = c;
        price = 0;
    }
    public String getProducer ()
    {
        return producer;
    }

    public void setProducer (String producer)
    {
        this.producer = producer;
    }

    public Book()
    {
        producer = "=";
        price = 100;
    }

    public int getPrice()
    {
        return price;
    }

    public void setPrice(int price)
    {
        this.price = price;
    }

    public String toString()
    {
        return "Book made by "+this.producer+ " and it cost "+this.price +"$";
    }
    public void InfoBook()
    {
        System.out.println ("Book made by "+this.producer + " and it cost " +this.price *15 +"rub");
    }
}
